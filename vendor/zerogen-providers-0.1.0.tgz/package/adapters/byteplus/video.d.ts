import { type BytePlus } from "byteplus-js";
import type { VideoGenerator, VideoRequest } from "../../ports/video.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
export interface BytePlusVideoOptions {
    /** Inject a client (tests). Otherwise a client is built per call. */
    client?: BytePlus;
    /** Override client construction (tests/proxies). */
    createClient?: (apiKey: string) => BytePlus;
}
/**
 * BytePlus Seedance video generation behind the {@link VideoGenerator} port.
 *
 * Seedance is an async task API; `seedance.subscribe` submits and polls
 * internally until a terminal state, so `generate` resolves only once the video
 * URL is ready (progress is surfaced via `context.onUpdate`). The returned asset
 * is a remote URL — the workflow's `materializeAsset` downloads it (with its
 * size/host/timeout guards).
 */
export declare class BytePlusVideoGenerator implements VideoGenerator {
    private readonly options;
    readonly provider = "byteplus";
    readonly capability: "video";
    constructor(options?: BytePlusVideoOptions);
    generate(request: VideoRequest, context?: ProviderCallContext): Promise<ProviderResult>;
    private resolveClient;
}
