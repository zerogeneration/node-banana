import { createBytePlus, estimateCost } from "byteplus-js";
import { ProviderError, } from "../../ports/types.js";
import { resolveApiKey } from "../../secrets.js";
/**
 * BytePlus Seedance video generation behind the {@link VideoGenerator} port.
 *
 * Seedance is an async task API; `seedance.subscribe` submits and polls
 * internally until a terminal state, so `generate` resolves only once the video
 * URL is ready (progress is surfaced via `context.onUpdate`). The returned asset
 * is a remote URL — the workflow's `materializeAsset` downloads it (with its
 * size/host/timeout guards).
 */
export class BytePlusVideoGenerator {
    options;
    provider = "byteplus";
    capability = "video";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = this.resolveClient(context);
        context.onUpdate?.("running");
        let task;
        try {
            task = await client.seedance.subscribe({
                // extra first so it cannot override canonical fields or the control args.
                ...(request.extra ?? {}),
                model: request.model,
                ...(request.prompt ? { prompt: request.prompt } : {}),
                ...(request.images && request.images.length > 0 ? { referenceImages: request.images } : {}),
                ...(request.ratio ? { ratio: request.ratio } : {}),
                ...(request.durationSeconds != null ? { duration: request.durationSeconds } : {}),
                ...(request.generateAudio != null ? { generateAudio: request.generateAudio } : {}),
                ...(context.signal ? { signal: context.signal } : {}),
                onUpdate: (t) => {
                    if (t.status !== "succeeded")
                        context.onUpdate?.("running");
                },
            });
        }
        catch (error) {
            context.onUpdate?.("failed");
            throw ProviderError.from("byteplus", error);
        }
        const videoUrl = task.videoUrl;
        if (!videoUrl) {
            context.onUpdate?.("failed");
            throw new ProviderError("byteplus", `Seedance task ${task.id} produced no video URL (status ${task.status ?? "unknown"}).`);
        }
        const meta = {};
        if (task.resolution)
            meta.resolution = task.resolution;
        // The last-frame URL is a signed/expiring CDN link — record only that one
        // exists, never the URL itself (it would be persisted indefinitely).
        if (task.lastFrameUrl)
            meta.hasLastFrame = true;
        const asset = {
            kind: "video",
            mimeType: "video/mp4",
            url: videoUrl,
            ...(Object.keys(meta).length > 0 ? { meta } : {}),
        };
        // Best-effort cost; the pricing table may not cover every model/option.
        let estimatedCostUsd;
        try {
            estimatedCostUsd = estimateCost(task).amountUsd;
        }
        catch {
            estimatedCostUsd = undefined;
        }
        context.onUpdate?.("succeeded");
        return {
            requestId: task.id,
            assets: [asset],
            usage: {
                provider: "byteplus",
                model: request.model,
                ...(task.completionTokens != null ? { tokens: task.completionTokens } : {}),
                ...(estimatedCostUsd != null ? { estimatedCostUsd } : {}),
                raw: task.usage,
            },
            raw: task.raw,
        };
    }
    resolveClient(context) {
        if (this.options.client)
            return this.options.client;
        // BytePlus ModelArk also accepts ARK_API_KEY as an alias (matches .env.example
        // and byteplus-js's own env fallback).
        const apiKey = resolveApiKey("byteplus", context.apiKey) ?? (process.env.ARK_API_KEY?.trim() || undefined);
        if (!apiKey) {
            throw new ProviderError("byteplus", "Missing BytePlus API key (set BYTEPLUS_API_KEY or ARK_API_KEY, or pass context.apiKey).");
        }
        return this.options.createClient ? this.options.createClient(apiKey) : createBytePlus({ apiKey });
    }
}
