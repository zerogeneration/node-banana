import type { SpeechGenerator, SpeechRequest } from "../../ports/audio.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
import { type ElevenLabsOptions } from "./shared.js";
/** ElevenLabs text-to-speech behind the {@link SpeechGenerator} port. */
export declare class ElevenLabsSpeechGenerator implements SpeechGenerator {
    private readonly options;
    readonly provider = "elevenlabs";
    readonly capability: "speech";
    constructor(options?: ElevenLabsOptions);
    generate(request: SpeechRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
