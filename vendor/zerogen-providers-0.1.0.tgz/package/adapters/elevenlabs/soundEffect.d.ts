import type { SoundEffectGenerator, SoundEffectRequest } from "../../ports/audio.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
import { type ElevenLabsOptions } from "./shared.js";
/** ElevenLabs sound-effect generation behind the {@link SoundEffectGenerator} port. */
export declare class ElevenLabsSoundEffectGenerator implements SoundEffectGenerator {
    private readonly options;
    readonly provider = "elevenlabs";
    readonly capability: "soundEffect";
    constructor(options?: ElevenLabsOptions);
    generate(request: SoundEffectRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
