import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";
import { type ProviderCallContext } from "../../ports/types.js";
export interface ElevenLabsOptions {
    /** Inject a client (tests). Otherwise a client is built per call. */
    client?: ElevenLabsClient;
    /** Override client construction (tests/proxies). */
    createClient?: (apiKey: string) => ElevenLabsClient;
}
export declare function resolveElevenLabsClient(options: ElevenLabsOptions, context: ProviderCallContext): ElevenLabsClient;
/** Collect a web ReadableStream into a Buffer, enforcing the cap as it reads. */
export declare function streamToBuffer(stream: ReadableStream<Uint8Array>, maxBytes?: number): Promise<Buffer>;
/** Map an ElevenLabs output_format (e.g. "mp3_44100_128") to a MIME type. */
export declare function audioMimeFor(outputFormat?: string): string;
