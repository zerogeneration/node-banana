import { randomUUID } from "node:crypto";
import { ProviderError } from "../../ports/types.js";
import { ELEVENLABS_MUSIC_MODEL } from "../../defaults.js";
import { audioMimeFor, resolveElevenLabsClient, streamToBuffer } from "./shared.js";
/** ElevenLabs music generation behind the {@link MusicGenerator} port. */
export class ElevenLabsMusicGenerator {
    options;
    provider = "elevenlabs";
    capability = "music";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = resolveElevenLabsClient(this.options, context);
        const modelId = request.model ?? ELEVENLABS_MUSIC_MODEL;
        context.onUpdate?.("running");
        let stream;
        try {
            stream = await client.music.compose({
                ...(request.extra ?? {}),
                prompt: request.prompt,
                modelId: modelId,
                ...(request.lengthMs != null ? { musicLengthMs: request.lengthMs } : {}),
                ...(request.outputFormat ? { outputFormat: request.outputFormat } : {}),
            });
        }
        catch (error) {
            context.onUpdate?.("failed");
            throw ProviderError.from("elevenlabs", error);
        }
        const bytes = await streamToBuffer(stream);
        context.onUpdate?.("succeeded");
        return {
            requestId: randomUUID(),
            assets: [{ kind: "audio", mimeType: audioMimeFor(request.outputFormat), bytes }],
            usage: { provider: "elevenlabs", model: modelId },
            raw: { bytes: bytes.length },
        };
    }
}
