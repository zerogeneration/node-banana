import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";
import { ProviderError } from "../../ports/types.js";
import { resolveApiKey } from "../../secrets.js";
export function resolveElevenLabsClient(options, context) {
    if (options.client)
        return options.client;
    const apiKey = resolveApiKey("elevenlabs", context.apiKey);
    if (!apiKey) {
        throw new ProviderError("elevenlabs", "Missing ElevenLabs API key (set ELEVENLABS_API_KEY or pass context.apiKey).");
    }
    return options.createClient ? options.createClient(apiKey) : new ElevenLabsClient({ apiKey });
}
/** Hard cap on a buffered audio stream (defense against unbounded responses). */
const DEFAULT_MAX_AUDIO_BYTES = 256 * 1024 * 1024;
/** Collect a web ReadableStream into a Buffer, enforcing the cap as it reads. */
export async function streamToBuffer(stream, maxBytes = DEFAULT_MAX_AUDIO_BYTES) {
    const reader = stream.getReader();
    const chunks = [];
    let total = 0;
    for (;;) {
        const { done, value } = await reader.read();
        if (done)
            break;
        if (!value)
            continue;
        total += value.length;
        if (total > maxBytes) {
            await reader.cancel().catch(() => undefined);
            throw new Error(`ElevenLabs audio exceeds ${maxBytes} bytes.`);
        }
        chunks.push(value);
    }
    return Buffer.concat(chunks);
}
/** Map an ElevenLabs output_format (e.g. "mp3_44100_128") to a MIME type. */
export function audioMimeFor(outputFormat) {
    const format = (outputFormat ?? "mp3").toLowerCase();
    if (format.startsWith("mp3"))
        return "audio/mpeg";
    if (format.startsWith("opus"))
        return "audio/opus";
    if (format.startsWith("pcm"))
        return "audio/L16";
    if (format.startsWith("ulaw") || format.startsWith("mulaw"))
        return "audio/basic";
    if (format.startsWith("wav"))
        return "audio/wav";
    return "audio/mpeg";
}
