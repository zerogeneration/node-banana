import { randomUUID } from "node:crypto";
import { ProviderError } from "../../ports/types.js";
import { ELEVENLABS_SPEECH_MODEL } from "../../defaults.js";
import { audioMimeFor, resolveElevenLabsClient, streamToBuffer } from "./shared.js";
/** Default public voice ("Rachel") when the request omits one. */
const DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM";
/** ElevenLabs text-to-speech behind the {@link SpeechGenerator} port. */
export class ElevenLabsSpeechGenerator {
    options;
    provider = "elevenlabs";
    capability = "speech";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = resolveElevenLabsClient(this.options, context);
        const voiceId = request.voiceId ?? DEFAULT_VOICE_ID;
        const modelId = request.model ?? ELEVENLABS_SPEECH_MODEL;
        context.onUpdate?.("running");
        let stream;
        try {
            stream = await client.textToSpeech.convert(voiceId, {
                ...(request.extra ?? {}),
                text: request.text,
                modelId,
                ...(request.outputFormat ? { outputFormat: request.outputFormat } : {}),
            });
        }
        catch (error) {
            context.onUpdate?.("failed");
            throw ProviderError.from("elevenlabs", error);
        }
        const bytes = await streamToBuffer(stream);
        context.onUpdate?.("succeeded");
        return {
            requestId: randomUUID(),
            assets: [{ kind: "audio", mimeType: audioMimeFor(request.outputFormat), bytes, meta: { voiceId } }],
            usage: { provider: "elevenlabs", model: modelId },
            raw: { bytes: bytes.length, voiceId },
        };
    }
}
