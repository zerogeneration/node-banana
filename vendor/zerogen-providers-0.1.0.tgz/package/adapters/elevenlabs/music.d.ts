import type { MusicGenerator, MusicRequest } from "../../ports/audio.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
import { type ElevenLabsOptions } from "./shared.js";
/** ElevenLabs music generation behind the {@link MusicGenerator} port. */
export declare class ElevenLabsMusicGenerator implements MusicGenerator {
    private readonly options;
    readonly provider = "elevenlabs";
    readonly capability: "music";
    constructor(options?: ElevenLabsOptions);
    generate(request: MusicRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
