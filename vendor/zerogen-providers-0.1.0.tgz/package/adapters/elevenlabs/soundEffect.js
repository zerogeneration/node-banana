import { randomUUID } from "node:crypto";
import { ProviderError } from "../../ports/types.js";
import { ELEVENLABS_SFX_MODEL } from "../../defaults.js";
import { audioMimeFor, resolveElevenLabsClient, streamToBuffer } from "./shared.js";
/** ElevenLabs sound-effect generation behind the {@link SoundEffectGenerator} port. */
export class ElevenLabsSoundEffectGenerator {
    options;
    provider = "elevenlabs";
    capability = "soundEffect";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = resolveElevenLabsClient(this.options, context);
        const modelId = request.model ?? ELEVENLABS_SFX_MODEL;
        context.onUpdate?.("running");
        let stream;
        try {
            stream = await client.textToSoundEffects.convert({
                ...(request.extra ?? {}),
                text: request.prompt,
                modelId,
                ...(request.durationSeconds != null ? { durationSeconds: request.durationSeconds } : {}),
                ...(request.outputFormat ? { outputFormat: request.outputFormat } : {}),
            });
        }
        catch (error) {
            context.onUpdate?.("failed");
            throw ProviderError.from("elevenlabs", error);
        }
        const bytes = await streamToBuffer(stream);
        context.onUpdate?.("succeeded");
        return {
            requestId: randomUUID(),
            assets: [{ kind: "audio", mimeType: audioMimeFor(request.outputFormat), bytes }],
            usage: { provider: "elevenlabs", model: modelId },
            raw: { bytes: bytes.length },
        };
    }
}
