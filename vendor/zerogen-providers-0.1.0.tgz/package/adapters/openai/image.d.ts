import OpenAI from "openai";
import type { ImageGenerator, ImageRequest } from "../../ports/image.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
export interface OpenAIImageOptions {
    /** Inject a client (tests). Otherwise a client is built per call. */
    client?: OpenAI;
    /** Override client construction (tests/proxies). */
    createClient?: (apiKey: string) => OpenAI;
}
/**
 * OpenAI image generation (e.g. `gpt-image-2`) behind the {@link ImageGenerator}
 * port. gpt-image models always return base64 (no URL). Uses the dedicated
 * Images API; a Responses-API-backed implementation can later sit behind the
 * same port for multi-turn editing.
 *
 * A fresh client is built per call (keyed by the resolved BYOK key) rather than
 * cached in a long-lived map — the SDK pools connections internally, and caching
 * by the raw key would both leak keys into memory and grow unbounded.
 */
export declare class OpenAIImageGenerator implements ImageGenerator {
    private readonly options;
    readonly provider = "openai";
    readonly capability: "image";
    constructor(options?: OpenAIImageOptions);
    generate(request: ImageRequest, context?: ProviderCallContext): Promise<ProviderResult>;
    private resolveClient;
}
