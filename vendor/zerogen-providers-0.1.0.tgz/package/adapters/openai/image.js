import { randomUUID } from "node:crypto";
import OpenAI from "openai";
import { ProviderError, parseSize, } from "../../ports/types.js";
import { resolveApiKey } from "../../secrets.js";
/**
 * OpenAI image generation (e.g. `gpt-image-2`) behind the {@link ImageGenerator}
 * port. gpt-image models always return base64 (no URL). Uses the dedicated
 * Images API; a Responses-API-backed implementation can later sit behind the
 * same port for multi-turn editing.
 *
 * A fresh client is built per call (keyed by the resolved BYOK key) rather than
 * cached in a long-lived map — the SDK pools connections internally, and caching
 * by the raw key would both leak keys into memory and grow unbounded.
 */
export class OpenAIImageGenerator {
    options;
    provider = "openai";
    capability = "image";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = this.resolveClient(context);
        const body = {
            // extra first so canonical fields below cannot be overridden by it
            // (keeps usage.model + the workflow input snapshot truthful).
            ...(request.extra ?? {}),
            model: request.model,
            prompt: request.prompt,
            ...(request.n != null ? { n: request.n } : {}),
            ...(request.size ? { size: request.size } : {}),
            ...(request.quality ? { quality: request.quality } : {}),
            ...(request.outputFormat ? { output_format: request.outputFormat } : {}),
            ...(request.background ? { background: request.background } : {}),
        };
        context.onUpdate?.("running");
        let response;
        try {
            response = await client.images.generate(body, context.signal ? { signal: context.signal } : undefined);
        }
        catch (error) {
            context.onUpdate?.("failed");
            throw ProviderError.from("openai", error);
        }
        const format = response.output_format ?? request.outputFormat ?? "png";
        const { width, height } = parseSize(response.size ?? request.size);
        // Return every generated image (honors n > 1), in order. gpt-image models
        // return base64; dall-e models return a URL unless response_format=b64_json,
        // so accept either (the materializer downloads URL assets).
        const assets = [];
        for (const image of response.data ?? []) {
            const dims = {
                ...(width !== undefined ? { width } : {}),
                ...(height !== undefined ? { height } : {}),
            };
            if (typeof image.b64_json === "string") {
                assets.push({ kind: "image", mimeType: `image/${format}`, base64: image.b64_json, ...dims });
            }
            else if (typeof image.url === "string") {
                assets.push({ kind: "image", mimeType: `image/${format}`, url: image.url, ...dims });
            }
        }
        if (assets.length === 0) {
            context.onUpdate?.("failed");
            throw new ProviderError("openai", "OpenAI returned no image data.");
        }
        context.onUpdate?.("succeeded");
        return {
            requestId: randomUUID(),
            assets,
            usage: {
                provider: "openai",
                model: request.model,
                ...(response.usage?.total_tokens !== undefined ? { tokens: response.usage.total_tokens } : {}),
                raw: response.usage,
            },
            raw: response,
        };
    }
    resolveClient(context) {
        if (this.options.client)
            return this.options.client;
        const apiKey = resolveApiKey("openai", context.apiKey);
        if (!apiKey) {
            throw new ProviderError("openai", "Missing OpenAI API key (set OPENAI_API_KEY or pass context.apiKey).");
        }
        return this.options.createClient ? this.options.createClient(apiKey) : new OpenAI({ apiKey });
    }
}
