import { type FalClient } from "@fal-ai/client";
import { type GenAsset, type MediaKind, type ProviderCallContext } from "../../ports/types.js";
export interface FalOptions {
    /** Inject a client (tests). Otherwise a client is built per call. */
    client?: FalClient;
    /** Override client construction (tests/proxies). */
    createClient?: (apiKey: string) => FalClient;
}
export declare function resolveFalClient(options: FalOptions, context: ProviderCallContext): FalClient;
export declare function falSubscribe(client: FalClient, model: string, input: Record<string, unknown>, context: ProviderCallContext): Promise<{
    data: Record<string, unknown>;
    requestId: string;
}>;
/**
 * fal output schemas vary per model. Scan the result `data` for the common media
 * shapes ({images:[{url}]}, {image|video|audio|audio_file:{url}}, {file:{url}})
 * and normalize each to a GenAsset (kind inferred from content_type, else the
 * field's fallback).
 */
export declare function normalizeFalAssets(data: Record<string, unknown>, fallback: MediaKind): GenAsset[];
