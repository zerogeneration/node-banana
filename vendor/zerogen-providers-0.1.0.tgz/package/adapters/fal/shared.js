import { createFalClient } from "@fal-ai/client";
import { ProviderError, } from "../../ports/types.js";
import { resolveApiKey } from "../../secrets.js";
export function resolveFalClient(options, context) {
    if (options.client)
        return options.client;
    const apiKey = resolveApiKey("fal", context.apiKey);
    if (!apiKey) {
        throw new ProviderError("fal", "Missing fal API key (set FAL_KEY or pass context.apiKey).");
    }
    return options.createClient ? options.createClient(apiKey) : createFalClient({ credentials: apiKey });
}
export async function falSubscribe(client, model, input, context) {
    const subscribe = client.subscribe.bind(client);
    context.onUpdate?.("running");
    try {
        return await subscribe(model, {
            input,
            onQueueUpdate: () => context.onUpdate?.("running"),
            ...(context.signal ? { signal: context.signal } : {}),
        });
    }
    catch (error) {
        context.onUpdate?.("failed");
        throw ProviderError.from("fal", error);
    }
}
function kindFromMime(mime) {
    if (mime.startsWith("image/"))
        return "image";
    if (mime.startsWith("video/"))
        return "video";
    if (mime.startsWith("audio/"))
        return "audio";
    return undefined;
}
function defaultMime(kind) {
    return kind === "image" ? "image/png" : kind === "video" ? "video/mp4" : kind === "audio" ? "audio/mpeg" : "application/octet-stream";
}
/**
 * fal output schemas vary per model. Scan the result `data` for the common media
 * shapes ({images:[{url}]}, {image|video|audio|audio_file:{url}}, {file:{url}})
 * and normalize each to a GenAsset (kind inferred from content_type, else the
 * field's fallback).
 */
export function normalizeFalAssets(data, fallback) {
    const assets = [];
    const push = (value, fallbackKind) => {
        if (!value || typeof value !== "object")
            return;
        const obj = value;
        const url = typeof obj.url === "string" ? obj.url : undefined;
        if (!url)
            return;
        const contentType = typeof obj.content_type === "string" ? obj.content_type : undefined;
        const kind = (contentType ? kindFromMime(contentType) : undefined) ?? fallbackKind;
        assets.push({
            kind,
            mimeType: contentType ?? defaultMime(kind),
            url,
            ...(typeof obj.width === "number" ? { width: obj.width } : {}),
            ...(typeof obj.height === "number" ? { height: obj.height } : {}),
        });
    };
    if (Array.isArray(data.images))
        for (const item of data.images)
            push(item, "image");
    if (Array.isArray(data.videos))
        for (const item of data.videos)
            push(item, "video");
    push(data.image, "image");
    push(data.video, "video");
    push(data.audio, "audio");
    push(data.audio_file, "audio");
    push(data.file, fallback);
    return assets;
}
