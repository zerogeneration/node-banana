import type { ImageGenerator, ImageRequest } from "../../ports/image.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
import { type FalOptions } from "./shared.js";
/**
 * fal.ai image generation behind the {@link ImageGenerator} port. The fal model
 * id is passed as `request.model` (e.g. "fal-ai/flux/dev"); model-specific input
 * fields go in `request.extra`. Output media is normalized from the fal result.
 */
export declare class FalImageGenerator implements ImageGenerator {
    private readonly options;
    readonly provider = "fal";
    readonly capability: "image";
    constructor(options?: FalOptions);
    generate(request: ImageRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
