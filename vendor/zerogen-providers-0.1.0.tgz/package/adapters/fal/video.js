import { ProviderError } from "../../ports/types.js";
import { falSubscribe, normalizeFalAssets, resolveFalClient } from "./shared.js";
/**
 * fal.ai video generation behind the {@link VideoGenerator} port. The fal model
 * id is passed as `request.model`; model-specific fields go in `request.extra`.
 * fal polls internally, so `generate` resolves once the result is ready.
 */
export class FalVideoGenerator {
    options;
    provider = "fal";
    capability = "video";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = resolveFalClient(this.options, context);
        const input = {
            ...(request.extra ?? {}),
            ...(request.prompt ? { prompt: request.prompt } : {}),
            ...(request.images && request.images.length > 0 ? { image_url: request.images[0] } : {}),
            ...(request.ratio ? { aspect_ratio: request.ratio } : {}),
            ...(request.durationSeconds != null ? { duration: request.durationSeconds } : {}),
            ...(request.generateAudio != null ? { generate_audio: request.generateAudio } : {}),
        };
        const { data, requestId } = await falSubscribe(client, request.model, input, context);
        const assets = normalizeFalAssets(data, "video");
        if (assets.length === 0) {
            context.onUpdate?.("failed");
            throw new ProviderError("fal", `fal model ${request.model} returned no media assets.`);
        }
        context.onUpdate?.("succeeded");
        return {
            requestId,
            assets,
            usage: { provider: "fal", model: request.model, raw: data.timings ?? undefined },
            raw: data,
        };
    }
}
