import { ProviderError } from "../../ports/types.js";
import { falSubscribe, normalizeFalAssets, resolveFalClient } from "./shared.js";
/**
 * fal's Flux `image_size` is an enum string ("square_hd", …) or a
 * `{ width, height }` object — not "WxH". Convert the CLI's WIDTHxHEIGHT to the
 * object form; pass any other string through as a presumed enum value.
 */
function toFalImageSize(size) {
    const match = /^(\d+)x(\d+)$/u.exec(size);
    return match ? { width: Number(match[1]), height: Number(match[2]) } : size;
}
/**
 * fal.ai image generation behind the {@link ImageGenerator} port. The fal model
 * id is passed as `request.model` (e.g. "fal-ai/flux/dev"); model-specific input
 * fields go in `request.extra`. Output media is normalized from the fal result.
 */
export class FalImageGenerator {
    options;
    provider = "fal";
    capability = "image";
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, context = {}) {
        const client = resolveFalClient(this.options, context);
        const input = {
            ...(request.extra ?? {}),
            prompt: request.prompt,
            ...(request.images && request.images.length > 0
                ? { image_url: request.images[0], image_urls: request.images }
                : {}),
            ...(request.size ? { image_size: toFalImageSize(request.size) } : {}),
            ...(request.n != null ? { num_images: request.n } : {}),
        };
        const { data, requestId } = await falSubscribe(client, request.model, input, context);
        const assets = normalizeFalAssets(data, "image");
        if (assets.length === 0) {
            context.onUpdate?.("failed");
            throw new ProviderError("fal", `fal model ${request.model} returned no media assets.`);
        }
        context.onUpdate?.("succeeded");
        return {
            requestId,
            assets,
            usage: { provider: "fal", model: request.model, raw: data.timings ?? undefined },
            raw: data,
        };
    }
}
