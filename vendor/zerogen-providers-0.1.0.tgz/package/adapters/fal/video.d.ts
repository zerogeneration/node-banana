import type { VideoGenerator, VideoRequest } from "../../ports/video.js";
import { type ProviderCallContext, type ProviderResult } from "../../ports/types.js";
import { type FalOptions } from "./shared.js";
/**
 * fal.ai video generation behind the {@link VideoGenerator} port. The fal model
 * id is passed as `request.model`; model-specific fields go in `request.extra`.
 * fal polls internally, so `generate` resolves once the result is ready.
 */
export declare class FalVideoGenerator implements VideoGenerator {
    private readonly options;
    readonly provider = "fal";
    readonly capability: "video";
    constructor(options?: FalOptions);
    generate(request: VideoRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
