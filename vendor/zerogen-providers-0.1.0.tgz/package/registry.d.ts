import type { MusicGenerator, SoundEffectGenerator, SpeechGenerator } from "./ports/audio.js";
import type { ImageGenerator } from "./ports/image.js";
import type { VideoGenerator } from "./ports/video.js";
export type Capability = "image" | "video" | "speech" | "music" | "soundEffect";
export declare const getImageGenerator: (provider: string) => Promise<ImageGenerator>;
export declare const getVideoGenerator: (provider: string) => Promise<VideoGenerator>;
export declare const getSpeechGenerator: (provider: string) => Promise<SpeechGenerator>;
export declare const getMusicGenerator: (provider: string) => Promise<MusicGenerator>;
export declare const getSoundEffectGenerator: (provider: string) => Promise<SoundEffectGenerator>;
export interface ProviderInfo {
    provider: string;
    capability: Capability;
    secretRef: string;
}
export declare function listProviders(): ProviderInfo[];
