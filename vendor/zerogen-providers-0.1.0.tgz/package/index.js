// Public API for @zerogen/providers.
// Capability ports + shared types
export * from "./ports/index.js";
// Registry
export { getImageGenerator, getVideoGenerator, getSpeechGenerator, getMusicGenerator, getSoundEffectGenerator, listProviders, } from "./registry.js";
// Secrets
export { PROVIDER_SECRETS, resolveApiKey, resolvedSecretRef } from "./secrets.js";
// Default model ids (single source of truth for adapters + workflow wrappers)
export { defaultModelFor, ELEVENLABS_SPEECH_MODEL, ELEVENLABS_MUSIC_MODEL, ELEVENLABS_SFX_MODEL, } from "./defaults.js";
