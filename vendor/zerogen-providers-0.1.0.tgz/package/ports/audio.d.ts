import type { ProviderCallContext, ProviderResult } from "./types.js";
export interface SpeechRequest {
    /** Optional — the provider selects a default model when omitted. */
    model?: string;
    text: string;
    voiceId?: string;
    outputFormat?: string;
    extra?: Record<string, unknown>;
}
export interface SpeechGenerator {
    readonly provider: string;
    readonly capability: "speech";
    generate(request: SpeechRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
export interface MusicRequest {
    /** Optional — the provider selects a default model when omitted. */
    model?: string;
    prompt: string;
    lengthMs?: number;
    outputFormat?: string;
    extra?: Record<string, unknown>;
}
export interface MusicGenerator {
    readonly provider: string;
    readonly capability: "music";
    generate(request: MusicRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
export interface SoundEffectRequest {
    model?: string;
    prompt: string;
    durationSeconds?: number;
    outputFormat?: string;
    extra?: Record<string, unknown>;
}
export interface SoundEffectGenerator {
    readonly provider: string;
    readonly capability: "soundEffect";
    generate(request: SoundEffectRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
