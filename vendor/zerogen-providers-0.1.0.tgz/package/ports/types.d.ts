/** Media kinds a provider can emit. */
export type MediaKind = "image" | "video" | "audio" | "model3d";
/** A single generated artifact. Exactly one of base64/url/bytes carries the payload. */
export interface GenAsset {
    kind: MediaKind;
    mimeType: string;
    base64?: string;
    url?: string;
    bytes?: Uint8Array;
    width?: number;
    height?: number;
    durationMs?: number;
    meta?: Record<string, unknown>;
}
/** Best-effort, normalized usage/cost for a generation. */
export interface GenUsage {
    provider: string;
    model: string;
    estimatedCostUsd?: number;
    tokens?: number;
    /** Raw provider usage object (no secrets). */
    raw?: unknown;
}
/** Normalized result returned by every capability port. */
export interface ProviderResult {
    requestId: string;
    assets: GenAsset[];
    usage?: GenUsage;
    /** Raw provider response, for debugging/provenance (no secrets). */
    raw: unknown;
}
export type ProviderStatus = "queued" | "running" | "succeeded" | "failed";
/** Per-call context. `apiKey` enables BYOK; otherwise the provider's env var is used. */
export interface ProviderCallContext {
    apiKey?: string;
    signal?: AbortSignal;
    onUpdate?: (status: ProviderStatus) => void;
}
/** Normalized provider error (never carries secrets). */
export declare class ProviderError extends Error {
    name: string;
    readonly provider: string;
    readonly code?: string;
    readonly status?: number;
    readonly retryable?: boolean;
    constructor(provider: string, message: string, options?: {
        code?: string;
        status?: number;
        retryable?: boolean;
        cause?: unknown;
    });
    static from(provider: string, error: unknown): ProviderError;
}
/** Parse a `WIDTHxHEIGHT` size string into numbers (undefined for "auto"/unknown). */
export declare function parseSize(size?: string): {
    width?: number;
    height?: number;
};
