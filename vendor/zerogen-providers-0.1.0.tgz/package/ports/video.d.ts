import type { ProviderCallContext, ProviderResult } from "./types.js";
export interface VideoRequest {
    model: string;
    prompt?: string;
    /** Reference / first-frame images (data URLs or http URLs). */
    images?: string[];
    /** e.g. "16:9". */
    ratio?: string;
    durationSeconds?: number;
    generateAudio?: boolean;
    /** Escape hatch for provider-specific params. */
    extra?: Record<string, unknown>;
}
/**
 * Capability port for video generation. Implementations may be long-running
 * (submit + poll); `generate` runs to completion and reports progress via
 * `context.onUpdate`.
 */
export interface VideoGenerator {
    readonly provider: string;
    readonly capability: "video";
    generate(request: VideoRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
