import type { ProviderCallContext, ProviderResult } from "./types.js";
export interface ImageRequest {
    model: string;
    prompt: string;
    /** Input images (data URLs or http URLs) for edit / image-to-image. */
    images?: string[];
    /** e.g. "1024x1024", "1536x1024", "auto". */
    size?: string;
    quality?: string;
    background?: string;
    outputFormat?: "png" | "jpeg" | "webp";
    n?: number;
    /** Escape hatch for provider-specific params. */
    extra?: Record<string, unknown>;
}
/** Capability port for image generation. */
export interface ImageGenerator {
    readonly provider: string;
    readonly capability: "image";
    generate(request: ImageRequest, context?: ProviderCallContext): Promise<ProviderResult>;
}
