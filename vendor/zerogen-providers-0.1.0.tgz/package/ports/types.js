/** Normalized provider error (never carries secrets). */
export class ProviderError extends Error {
    name = "ProviderError";
    provider;
    code;
    status;
    retryable;
    constructor(provider, message, options = {}) {
        super(`[${provider}] ${message}`, options.cause !== undefined ? { cause: options.cause } : undefined);
        this.provider = provider;
        this.code = options.code;
        this.status = options.status;
        this.retryable = options.retryable;
    }
    static from(provider, error) {
        if (error instanceof ProviderError)
            return error;
        const message = error instanceof Error ? error.message : String(error);
        let status;
        let code;
        if (error && typeof error === "object") {
            const candidate = error;
            if (typeof candidate.status === "number")
                status = candidate.status;
            if (typeof candidate.code === "string")
                code = candidate.code;
        }
        // Deliberately does NOT attach the raw provider error as `cause`: SDK errors
        // (e.g. OpenAI's APIError) can carry request/response headers — including the
        // Authorization token — which must never escape the adapter or reach an
        // error-tracking sink. We keep only the scrubbed status/code/message.
        return new ProviderError(provider, message, { status, code });
    }
}
/** Parse a `WIDTHxHEIGHT` size string into numbers (undefined for "auto"/unknown). */
export function parseSize(size) {
    if (!size)
        return {};
    const match = /^(\d+)x(\d+)$/u.exec(size);
    if (!match)
        return {};
    return { width: Number(match[1]), height: Number(match[2]) };
}
