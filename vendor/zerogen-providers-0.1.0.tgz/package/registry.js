import { PROVIDER_SECRETS } from "./secrets.js";
// Adapters are loaded lazily (dynamic import) so importing the registry — or
// @zerogen/core, which re-exports it — does NOT pull each provider SDK into the
// module graph. The SDK loads only when its generator is actually requested.
const imageFactories = {
    openai: async () => new (await import("./adapters/openai/image.js")).OpenAIImageGenerator(),
    fal: async () => new (await import("./adapters/fal/image.js")).FalImageGenerator(),
};
const videoFactories = {
    byteplus: async () => new (await import("./adapters/byteplus/video.js")).BytePlusVideoGenerator(),
    fal: async () => new (await import("./adapters/fal/video.js")).FalVideoGenerator(),
};
const speechFactories = {
    elevenlabs: async () => new (await import("./adapters/elevenlabs/speech.js")).ElevenLabsSpeechGenerator(),
};
const musicFactories = {
    elevenlabs: async () => new (await import("./adapters/elevenlabs/music.js")).ElevenLabsMusicGenerator(),
};
const soundEffectFactories = {
    elevenlabs: async () => new (await import("./adapters/elevenlabs/soundEffect.js")).ElevenLabsSoundEffectGenerator(),
};
function resolveFrom(factories, capability, provider) {
    const factory = factories[provider];
    if (!factory) {
        throw new Error(`No ${capability} provider '${provider}'. Available: ${Object.keys(factories).join(", ") || "(none)"}.`);
    }
    return factory();
}
export const getImageGenerator = (provider) => resolveFrom(imageFactories, "image", provider);
export const getVideoGenerator = (provider) => resolveFrom(videoFactories, "video", provider);
export const getSpeechGenerator = (provider) => resolveFrom(speechFactories, "speech", provider);
export const getMusicGenerator = (provider) => resolveFrom(musicFactories, "music", provider);
export const getSoundEffectGenerator = (provider) => resolveFrom(soundEffectFactories, "soundEffect", provider);
export function listProviders() {
    // Every registered factory key is expected to have a PROVIDER_SECRETS entry;
    // "" signals a missing mapping (a registration bug) rather than a real key.
    const secretFor = (p) => PROVIDER_SECRETS[p] ?? "";
    const groups = [
        ["image", imageFactories],
        ["video", videoFactories],
        ["speech", speechFactories],
        ["music", musicFactories],
        ["soundEffect", soundEffectFactories],
    ];
    return groups.flatMap(([capability, factories]) => Object.keys(factories).map((provider) => ({ provider, capability, secretRef: secretFor(provider) })));
}
