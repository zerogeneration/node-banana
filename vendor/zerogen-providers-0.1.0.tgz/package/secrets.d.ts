/**
 * Provider → environment-variable name for its API key. Only the NAME is a
 * stable reference; the value is read at call time (BYOK) and never persisted.
 */
export declare const PROVIDER_SECRETS: {
    readonly openai: "OPENAI_API_KEY";
    readonly byteplus: "BYTEPLUS_API_KEY";
    readonly fal: "FAL_KEY";
    readonly elevenlabs: "ELEVENLABS_API_KEY";
};
export type ProviderName = keyof typeof PROVIDER_SECRETS;
/** Resolve a provider's API key from explicit BYOK value, then its env var. */
export declare function resolveApiKey(provider: ProviderName, apiKey?: string): string | undefined;
/**
 * The env var NAME a non-BYOK run would actually read for this provider, for
 * accurate manifest provenance. BytePlus accepts ARK_API_KEY as an alias, so
 * report that when it is the credential present.
 */
export declare function resolvedSecretRef(provider: string): string;
