/**
 * Provider-specific default model ids. Single source of truth shared by the
 * adapters (which send these when a caller omits a model) and the workflow
 * wrappers (which record the resolved model in the run input), so the persisted
 * snapshot, the provider call, and `usage.model` always agree — and a default
 * run replays deterministically even if a default later changes.
 */
export const ELEVENLABS_SPEECH_MODEL = "eleven_multilingual_v2";
export const ELEVENLABS_MUSIC_MODEL = "music_v1";
export const ELEVENLABS_SFX_MODEL = "eleven_text_to_sound_v2";
const DEFAULT_MODELS = {
    speech: { elevenlabs: ELEVENLABS_SPEECH_MODEL },
    music: { elevenlabs: ELEVENLABS_MUSIC_MODEL },
    soundEffect: { elevenlabs: ELEVENLABS_SFX_MODEL },
};
/** The model a provider uses for a capability when the caller omits one. */
export function defaultModelFor(capability, provider) {
    return DEFAULT_MODELS[capability]?.[provider];
}
