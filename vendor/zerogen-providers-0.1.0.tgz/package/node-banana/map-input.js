// --- Capability routing -----------------------------------------------------
/**
 * node-banana capability tags (and common synonyms) → our {@link Capability}.
 *
 * node-banana's real `ModelCapability` vocabulary is task-shaped
 * ("text-to-image", "image-to-video", …); those are the values actually sent, so
 * they map first. `text-to-audio` is generic audio → defaults to `speech`;
 * elevenlabs sub-routing (speech vs music vs soundEffect) is decided by model id
 * in {@link generate.ts}, since node-banana can't express it via capability.
 * `text-to-3d` / `image-to-3d` are intentionally unmapped (no 3d capability).
 */
const CAPABILITY_ALIASES = {
    // node-banana ModelCapability values
    "text-to-image": "image",
    "image-to-image": "image",
    "text-to-video": "video",
    "image-to-video": "video",
    "audio-to-video": "video",
    "text-to-audio": "speech",
    // short synonyms / other consumers
    image: "image",
    video: "video",
    speech: "speech",
    tts: "speech",
    "text-to-speech": "speech",
    music: "music",
    soundeffect: "soundEffect",
    "sound-effect": "soundEffect",
    sound_effect: "soundEffect",
    sfx: "soundEffect",
};
/** Normalize a model's capability hint(s) to our capability vocabulary. */
export function normalizeCapabilities(model) {
    const raw = model.capabilities;
    const tags = Array.isArray(raw) ? raw : raw ? [raw] : [];
    const out = [];
    for (const tag of tags) {
        const cap = CAPABILITY_ALIASES[tag.toLowerCase().trim()];
        if (cap && !out.includes(cap))
            out.push(cap);
    }
    return out;
}
/**
 * Choose which capability to run: the first of the model's declared
 * capabilities that this provider supports, else `fallback`. Single-capability
 * providers pass a one-element `supported` and never really branch.
 */
export function pickCapability(model, supported, fallback) {
    return normalizeCapabilities(model).find((c) => supported.includes(c)) ?? fallback;
}
// --- Value coercion ---------------------------------------------------------
// `parameters` are typed `unknown` and `dynamicInputs` are `string | string[]`,
// so canonical fields are coerced defensively before reaching a typed request.
function strOpt(v) {
    return typeof v === "string" && v.length > 0 ? v : undefined;
}
function numOpt(v) {
    if (typeof v === "number" && Number.isFinite(v))
        return v;
    if (typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)))
        return Number(v);
    return undefined;
}
function boolOpt(v) {
    if (typeof v === "boolean")
        return v;
    if (v === "true")
        return true;
    if (v === "false")
        return false;
    return undefined;
}
function secondsToMs(seconds) {
    return seconds == null ? undefined : Math.round(seconds * 1000);
}
// --- Param / image collection ----------------------------------------------
/** Merge static parameters with live dynamicInputs (dynamic wins on conflict). */
function mergedParams(input) {
    return { ...(input.parameters ?? {}), ...(input.dynamicInputs ?? {}) };
}
/** Param keys that carry input images, so they route to `images`, not `extra`. */
const IMAGE_INPUT_KEYS = [
    "image",
    "images",
    "image_url",
    "image_urls",
    "referenceImages",
    "reference_images",
];
/** Gather input images from `input.images` plus any image-bearing params/inputs. */
function collectImages(input) {
    const out = [];
    if (input.images)
        out.push(...input.images);
    const bag = mergedParams(input);
    for (const key of IMAGE_INPUT_KEYS) {
        const v = bag[key];
        if (typeof v === "string")
            out.push(v);
        else if (Array.isArray(v))
            for (const item of v)
                if (typeof item === "string")
                    out.push(item);
    }
    const seen = new Set();
    const deduped = out.filter((u) => (seen.has(u) ? false : (seen.add(u), true)));
    return deduped.length > 0 ? deduped : undefined;
}
/** Everything in `params` except the consumed `keys`, for the `extra` escape hatch. */
function leftover(params, keys) {
    const rest = {};
    for (const [k, v] of Object.entries(params))
        if (!keys.includes(k))
            rest[k] = v;
    return rest;
}
/** node-banana's model.id is the model; an explicit `model` param may override. */
function modelId(input, params) {
    return strOpt(params.model) ?? strOpt(params.modelId) ?? input.model.id;
}
/**
 * Resolve the effective prompt. node-banana sends `prompt: ""` and the real text
 * via `dynamicInputs.prompt` when a Prompt Constructor node is wired in, so fall
 * back to the dynamic value (string or first array element) when the top-level
 * prompt is empty. Without this the canonical (empty) prompt would win and the
 * connected text would be lost.
 */
function resolvePrompt(input) {
    if (input.prompt)
        return input.prompt;
    const dynamic = input.dynamicInputs?.prompt;
    if (typeof dynamic === "string")
        return dynamic;
    if (Array.isArray(dynamic) && typeof dynamic[0] === "string")
        return dynamic[0];
    return input.prompt ?? "";
}
// --- Per-capability mappers -------------------------------------------------
const IMAGE_KEYS = [
    "prompt",
    "size",
    "quality",
    "background",
    "outputFormat",
    "output_format",
    "n",
    "model",
    "modelId",
    ...IMAGE_INPUT_KEYS,
];
function imageOutputFormat(params) {
    const v = strOpt(params.outputFormat) ?? strOpt(params.output_format);
    return v === "png" || v === "jpeg" || v === "webp" ? v : undefined;
}
export function toImageRequest(input) {
    const params = mergedParams(input);
    const images = collectImages(input);
    const rest = leftover(params, IMAGE_KEYS);
    const format = imageOutputFormat(params);
    return {
        model: modelId(input, params),
        prompt: resolvePrompt(input),
        ...(images ? { images } : {}),
        ...(strOpt(params.size) ? { size: strOpt(params.size) } : {}),
        ...(strOpt(params.quality) ? { quality: strOpt(params.quality) } : {}),
        ...(strOpt(params.background) ? { background: strOpt(params.background) } : {}),
        ...(format ? { outputFormat: format } : {}),
        ...(numOpt(params.n) != null ? { n: numOpt(params.n) } : {}),
        ...(Object.keys(rest).length > 0 ? { extra: rest } : {}),
    };
}
/**
 * fal image variant of {@link toImageRequest}. `FalImageGenerator` forwards
 * provider-specific fields from `extra` (plus prompt/images/image_size/num_images)
 * but does NOT read the canonical `outputFormat`, so we relocate it into
 * `extra.output_format` (fal's own field name) to avoid silently dropping it.
 */
export function toFalImageRequest(input) {
    const request = toImageRequest(input);
    if (!request.outputFormat)
        return request;
    const { outputFormat, extra, ...rest } = request;
    return { ...rest, extra: { ...(extra ?? {}), output_format: outputFormat } };
}
const VIDEO_KEYS = [
    "prompt",
    "ratio",
    "aspect_ratio",
    "aspectRatio",
    "duration",
    "durationSeconds",
    "duration_seconds",
    "generateAudio",
    "generate_audio",
    "model",
    "modelId",
    ...IMAGE_INPUT_KEYS,
];
export function toVideoRequest(input) {
    const params = mergedParams(input);
    const images = collectImages(input);
    const rest = leftover(params, VIDEO_KEYS);
    const prompt = resolvePrompt(input);
    const ratio = strOpt(params.ratio) ?? strOpt(params.aspect_ratio) ?? strOpt(params.aspectRatio);
    const duration = numOpt(params.durationSeconds) ?? numOpt(params.duration_seconds) ?? numOpt(params.duration);
    const generateAudio = boolOpt(params.generateAudio) ?? boolOpt(params.generate_audio);
    return {
        model: modelId(input, params),
        ...(prompt ? { prompt } : {}),
        ...(images ? { images } : {}),
        ...(ratio ? { ratio } : {}),
        ...(duration != null ? { durationSeconds: duration } : {}),
        ...(generateAudio != null ? { generateAudio } : {}),
        ...(Object.keys(rest).length > 0 ? { extra: rest } : {}),
    };
}
const SPEECH_KEYS = [
    "voiceId",
    "voice_id",
    "voice",
    "outputFormat",
    "output_format",
    "model",
    "modelId",
    "text",
    "prompt",
];
export function toSpeechRequest(input) {
    const params = mergedParams(input);
    const rest = leftover(params, SPEECH_KEYS);
    const voiceId = strOpt(params.voiceId) ?? strOpt(params.voice_id) ?? strOpt(params.voice);
    const outputFormat = strOpt(params.outputFormat) ?? strOpt(params.output_format);
    return {
        model: modelId(input, params),
        text: strOpt(params.text) ?? resolvePrompt(input),
        ...(voiceId ? { voiceId } : {}),
        ...(outputFormat ? { outputFormat } : {}),
        ...(Object.keys(rest).length > 0 ? { extra: rest } : {}),
    };
}
const MUSIC_KEYS = [
    "prompt",
    "lengthMs",
    "length_ms",
    "durationMs",
    "duration",
    "durationSeconds",
    "duration_seconds",
    "outputFormat",
    "output_format",
    "model",
    "modelId",
];
export function toMusicRequest(input) {
    const params = mergedParams(input);
    const rest = leftover(params, MUSIC_KEYS);
    const lengthMs = numOpt(params.lengthMs) ??
        numOpt(params.length_ms) ??
        numOpt(params.durationMs) ??
        secondsToMs(numOpt(params.durationSeconds) ?? numOpt(params.duration_seconds) ?? numOpt(params.duration));
    const outputFormat = strOpt(params.outputFormat) ?? strOpt(params.output_format);
    return {
        model: modelId(input, params),
        prompt: resolvePrompt(input),
        ...(lengthMs != null ? { lengthMs } : {}),
        ...(outputFormat ? { outputFormat } : {}),
        ...(Object.keys(rest).length > 0 ? { extra: rest } : {}),
    };
}
const SFX_KEYS = [
    "prompt",
    "durationSeconds",
    "duration_seconds",
    "duration",
    "outputFormat",
    "output_format",
    "model",
    "modelId",
];
export function toSoundEffectRequest(input) {
    const params = mergedParams(input);
    const rest = leftover(params, SFX_KEYS);
    const durationSeconds = numOpt(params.durationSeconds) ?? numOpt(params.duration_seconds) ?? numOpt(params.duration);
    const outputFormat = strOpt(params.outputFormat) ?? strOpt(params.output_format);
    return {
        model: modelId(input, params),
        prompt: resolvePrompt(input),
        ...(durationSeconds != null ? { durationSeconds } : {}),
        ...(outputFormat ? { outputFormat } : {}),
        ...(Object.keys(rest).length > 0 ? { extra: rest } : {}),
    };
}
