// node-banana binding for @zerogen/providers.
// Import from a node-banana fork via the `@zerogen/providers/node-banana` subpath.
export { generateWith, generateWithByteplus, generateWithElevenLabs, generateWithFal, generateWithOpenAI, nodeBananaProviders, } from "./generate.js";
export { toNbOutput } from "./map-output.js";
export { normalizeCapabilities, pickCapability, toFalImageRequest, toImageRequest, toMusicRequest, toSoundEffectRequest, toSpeechRequest, toVideoRequest, } from "./map-input.js";
