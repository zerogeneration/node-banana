import type { GenerationInput, GenerationOutput } from "./types.js";
export declare function generateWithOpenAI(requestId: string, apiKey: string, input: GenerationInput): Promise<GenerationOutput>;
export declare function generateWithByteplus(requestId: string, apiKey: string, input: GenerationInput): Promise<GenerationOutput>;
export declare function generateWithFal(requestId: string, apiKey: string, input: GenerationInput): Promise<GenerationOutput>;
export declare function generateWithElevenLabs(requestId: string, apiKey: string, input: GenerationInput): Promise<GenerationOutput>;
export type NodeBananaProvider = "openai" | "byteplus" | "fal" | "elevenlabs";
/** Provider name → binding, so node-banana's `route.ts` can dispatch in one line. */
export declare const nodeBananaProviders: Record<NodeBananaProvider, (requestId: string, apiKey: string, input: GenerationInput) => Promise<GenerationOutput>>;
/** Convenience dispatcher; unknown providers return a failure envelope (never throw). */
export declare function generateWith(provider: string, requestId: string, apiKey: string, input: GenerationInput): Promise<GenerationOutput>;
