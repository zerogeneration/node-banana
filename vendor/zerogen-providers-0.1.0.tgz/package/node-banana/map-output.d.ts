import type { GenAsset } from "../ports/types.js";
import type { NbOutput } from "./types.js";
/**
 * Convert one normalized {@link GenAsset} into node-banana's output shape.
 *
 * Our assets carry exactly one payload channel: `base64`, `bytes`, or a remote
 * `url`. node-banana renders `data` directly, so it must be a base64 **data URL**
 * (e.g. "data:image/png;base64,…"), NOT raw base64 — we store raw base64 plus a
 * separate `mimeType`, so we recombine them here.
 *
 * A url-only **image** is fetched and inlined, because node-banana ignores `url`
 * for images. A url-only video/audio/3d asset stays `{ data: "", url }` —
 * node-banana treats that as large media and fetches it lazily (so we never pull
 * a multi-hundred-MB video into the response).
 */
export declare function toNbOutput(asset: GenAsset): Promise<NbOutput>;
