import type { ImageRequest } from "../ports/image.js";
import type { VideoRequest } from "../ports/video.js";
import type { MusicRequest, SoundEffectRequest, SpeechRequest } from "../ports/audio.js";
import type { Capability } from "../registry.js";
import type { GenerationInput, ProviderModel } from "./types.js";
/** Normalize a model's capability hint(s) to our capability vocabulary. */
export declare function normalizeCapabilities(model: ProviderModel): Capability[];
/**
 * Choose which capability to run: the first of the model's declared
 * capabilities that this provider supports, else `fallback`. Single-capability
 * providers pass a one-element `supported` and never really branch.
 */
export declare function pickCapability(model: ProviderModel, supported: Capability[], fallback: Capability): Capability;
export declare function toImageRequest(input: GenerationInput): ImageRequest;
/**
 * fal image variant of {@link toImageRequest}. `FalImageGenerator` forwards
 * provider-specific fields from `extra` (plus prompt/images/image_size/num_images)
 * but does NOT read the canonical `outputFormat`, so we relocate it into
 * `extra.output_format` (fal's own field name) to avoid silently dropping it.
 */
export declare function toFalImageRequest(input: GenerationInput): ImageRequest;
export declare function toVideoRequest(input: GenerationInput): VideoRequest;
export declare function toSpeechRequest(input: GenerationInput): SpeechRequest;
export declare function toMusicRequest(input: GenerationInput): MusicRequest;
export declare function toSoundEffectRequest(input: GenerationInput): SoundEffectRequest;
