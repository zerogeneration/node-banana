/**
 * Local mirror of shrimbly/node-banana's provider contract.
 *
 * We deliberately do NOT import these from node-banana: per ADR-0018 the
 * dependency points the other way (node-banana imports `@zerogen/providers`,
 * not vice-versa). Keeping a structural copy here lets the binding type-check
 * standalone while staying drop-in compatible with node-banana's per-provider
 * dispatch. If node-banana's contract drifts, this file is the single place to
 * realign.
 */
export {};
