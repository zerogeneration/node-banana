import { getImageGenerator, getMusicGenerator, getSoundEffectGenerator, getSpeechGenerator, getVideoGenerator, } from "../registry.js";
import { ProviderError } from "../ports/types.js";
import { toNbOutput } from "./map-output.js";
import { normalizeCapabilities, pickCapability, toFalImageRequest, toImageRequest, toMusicRequest, toSoundEffectRequest, toSpeechRequest, toVideoRequest, } from "./map-input.js";
/**
 * node-banana provider binding over `@zerogen/providers`.
 *
 * Each `generateWith<Provider>` matches node-banana's per-provider dispatch
 * signature `(requestId, apiKey, input) => Promise<GenerationOutput>`. It maps
 * node-banana's request to our normalized port request, runs the (lazily loaded)
 * adapter to a terminal result — async video providers poll internally, so this
 * resolves only once the media is ready — and maps the result back. Errors are
 * caught and returned as a scrubbed `{ success: false, error }` envelope rather
 * than thrown, matching node-banana's contract.
 *
 * `requestId` is node-banana's own correlation id; our ports mint their own
 * provider request id (returned in `ProviderResult.requestId`), so it is part of
 * the signature for drop-in compatibility but not otherwise needed here.
 */
/**
 * BYOK passthrough: forward the **trimmed** key when non-empty; otherwise let the
 * adapter fall back to its env var. Trimming once here matches ADR-0013 (a pasted
 * key with surrounding whitespace must still authenticate) and keeps the check and
 * the forwarded value consistent.
 */
function ctx(apiKey) {
    const trimmed = apiKey?.trim();
    return trimmed ? { apiKey: trimmed } : {};
}
async function ok(result) {
    // toNbOutput may fetch+inline url-only images, so resolve all outputs together.
    return { success: true, outputs: await Promise.all(result.assets.map(toNbOutput)) };
}
/** Route every error through ProviderError.from, which strips secret-bearing causes. */
function fail(provider, error) {
    return { success: false, error: ProviderError.from(provider, error).message };
}
export async function generateWithOpenAI(requestId, apiKey, input) {
    try {
        const request = toImageRequest(input);
        // Our OpenAIImageGenerator hits the text-to-image Images API and never reads
        // request.images, so a connected reference image would be silently ignored.
        // Fail loudly instead of producing a misleading text-only result. (An
        // edit-capable OpenAI path can later route image-to-image through the same port.)
        if (request.images && request.images.length > 0) {
            throw new ProviderError("openai", "Input/reference images aren't supported by the OpenAI image binding yet (text-to-image only) — remove the connected image(s), or use an edit-capable provider.");
        }
        const generator = await getImageGenerator("openai");
        return await ok(await generator.generate(request, ctx(apiKey)));
    }
    catch (error) {
        return fail("openai", error);
    }
}
export async function generateWithByteplus(requestId, apiKey, input) {
    try {
        const generator = await getVideoGenerator("byteplus");
        return await ok(await generator.generate(toVideoRequest(input), ctx(apiKey)));
    }
    catch (error) {
        return fail("byteplus", error);
    }
}
export async function generateWithFal(requestId, apiKey, input) {
    try {
        const capability = pickCapability(input.model, ["image", "video"], "image");
        if (capability === "video") {
            const generator = await getVideoGenerator("fal");
            return await ok(await generator.generate(toVideoRequest(input), ctx(apiKey)));
        }
        const generator = await getImageGenerator("fal");
        return await ok(await generator.generate(toFalImageRequest(input), ctx(apiKey)));
    }
    catch (error) {
        return fail("fal", error);
    }
}
/**
 * Decide ElevenLabs' audio sub-capability. node-banana tags every audio model
 * as `text-to-audio`, so capability alone can't tell speech from music from sfx
 * — we infer from the model id first (matching our adapter defaults: "music_v1",
 * "eleven_text_to_sound_v2", "eleven_multilingual_v2"), then fall back to an
 * explicit capability hint if a consumer provides one, then default to speech.
 */
function elevenLabsCapability(input) {
    const id = input.model.id.toLowerCase();
    if (id.includes("music"))
        return "music";
    if (id.includes("sound") || id.includes("sfx"))
        return "soundEffect";
    const hinted = normalizeCapabilities(input.model);
    if (hinted.includes("music"))
        return "music";
    if (hinted.includes("soundEffect"))
        return "soundEffect";
    return "speech";
}
export async function generateWithElevenLabs(requestId, apiKey, input) {
    try {
        const capability = elevenLabsCapability(input);
        if (capability === "music") {
            const generator = await getMusicGenerator("elevenlabs");
            return await ok(await generator.generate(toMusicRequest(input), ctx(apiKey)));
        }
        if (capability === "soundEffect") {
            const generator = await getSoundEffectGenerator("elevenlabs");
            return await ok(await generator.generate(toSoundEffectRequest(input), ctx(apiKey)));
        }
        const generator = await getSpeechGenerator("elevenlabs");
        return await ok(await generator.generate(toSpeechRequest(input), ctx(apiKey)));
    }
    catch (error) {
        return fail("elevenlabs", error);
    }
}
/** Provider name → binding, so node-banana's `route.ts` can dispatch in one line. */
export const nodeBananaProviders = {
    openai: generateWithOpenAI,
    byteplus: generateWithByteplus,
    fal: generateWithFal,
    elevenlabs: generateWithElevenLabs,
};
/** Convenience dispatcher; unknown providers return a failure envelope (never throw). */
export function generateWith(provider, requestId, apiKey, input) {
    const binding = nodeBananaProviders[provider];
    if (!binding) {
        return Promise.resolve({ success: false, error: `Unknown provider '${provider}'.` });
    }
    return binding(requestId, apiKey, input);
}
