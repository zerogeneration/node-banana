/**
 * Local mirror of shrimbly/node-banana's provider contract.
 *
 * We deliberately do NOT import these from node-banana: per ADR-0018 the
 * dependency points the other way (node-banana imports `@zerogen/providers`,
 * not vice-versa). Keeping a structural copy here lets the binding type-check
 * standalone while staying drop-in compatible with node-banana's per-provider
 * dispatch. If node-banana's contract drifts, this file is the single place to
 * realign.
 */
/** A model entry as node-banana hands it to a provider. */
export interface ProviderModel {
    /** Provider-native model id, passed straight through to our ports. */
    id: string;
    /**
     * What the model produces. Used only to route multi-capability providers
     * (fal → image|video, elevenlabs → speech|music|soundEffect). Single-capability
     * providers (openai → image, byteplus → video) ignore it. Accepts a single tag
     * or a list; common synonyms ("tts", "sfx", …) are normalized — see
     * {@link normalizeCapabilities}.
     */
    capabilities?: string | string[];
}
/** node-banana's per-generation request payload. */
export interface GenerationInput {
    model: ProviderModel;
    prompt: string;
    /** Input images as data URLs or http(s) URLs (edit / image-to-image / first frame). */
    images?: string[];
    /** Static node parameters configured in the canvas UI. */
    parameters?: Record<string, unknown>;
    /** Live values wired from upstream nodes; override `parameters` on key conflict. */
    dynamicInputs?: Record<string, string | string[]>;
}
export type NbOutputType = "image" | "video" | "audio" | "3d";
/** A single node-banana output artifact. */
export interface NbOutput {
    type: NbOutputType;
    /** Raw base64 payload. Empty string when the asset is delivered url-only. */
    data: string;
    /** Remote URL for large / url-only media; node-banana fetches it lazily. */
    url?: string;
}
/** node-banana's per-generation result envelope. */
export interface GenerationOutput {
    success: boolean;
    outputs?: NbOutput[];
    /** Scrubbed, human-readable failure message (never carries secrets). */
    error?: string;
}
