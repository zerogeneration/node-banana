/** Our MediaKind → node-banana's output type. Only `model3d` is renamed ("3d"). */
const KIND_TO_NB = {
    image: "image",
    video: "video",
    audio: "audio",
    model3d: "3d",
};
/** Inline cap for a fetched image (the result is base64-embedded in the response). */
const MAX_INLINE_IMAGE_BYTES = 32 * 1024 * 1024;
/**
 * Fetch a remote image and return its base64 + mime. node-banana's
 * `buildMediaResponse` renders images from `data` only (it ignores `url` for the
 * image type, unlike video/audio/3d), so a url-only image MUST be inlined or it
 * renders blank. URLs here are provider-emitted (fal/openai CDN); fuller SSRF
 * hardening (DNS vetting, streaming caps) lives in the backend materializer
 * (ADR-0015) — here we just enforce http(s) and a size cap.
 */
async function fetchImageAsBase64(url, fallbackMime) {
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        throw new Error(`Invalid image asset URL.`);
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        throw new Error(`Unsupported image asset URL scheme: ${parsed.protocol}`);
    }
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch image asset (HTTP ${response.status}).`);
    }
    const declared = Number(response.headers.get("content-length"));
    if (Number.isFinite(declared) && declared > MAX_INLINE_IMAGE_BYTES) {
        throw new Error(`Image asset exceeds ${MAX_INLINE_IMAGE_BYTES} bytes.`);
    }
    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.byteLength > MAX_INLINE_IMAGE_BYTES) {
        throw new Error(`Image asset exceeds ${MAX_INLINE_IMAGE_BYTES} bytes.`);
    }
    const mimeType = response.headers.get("content-type")?.split(";")[0]?.trim() || fallbackMime;
    return { base64: buffer.toString("base64"), mimeType };
}
/**
 * Convert one normalized {@link GenAsset} into node-banana's output shape.
 *
 * Our assets carry exactly one payload channel: `base64`, `bytes`, or a remote
 * `url`. node-banana renders `data` directly, so it must be a base64 **data URL**
 * (e.g. "data:image/png;base64,…"), NOT raw base64 — we store raw base64 plus a
 * separate `mimeType`, so we recombine them here.
 *
 * A url-only **image** is fetched and inlined, because node-banana ignores `url`
 * for images. A url-only video/audio/3d asset stays `{ data: "", url }` —
 * node-banana treats that as large media and fetches it lazily (so we never pull
 * a multi-hundred-MB video into the response).
 */
export async function toNbOutput(asset) {
    const type = KIND_TO_NB[asset.kind];
    let base64 = asset.base64 ?? (asset.bytes ? Buffer.from(asset.bytes).toString("base64") : undefined);
    let mimeType = asset.mimeType;
    if (!base64 && type === "image" && asset.url) {
        const fetched = await fetchImageAsBase64(asset.url, asset.mimeType);
        base64 = fetched.base64;
        mimeType = fetched.mimeType;
    }
    return {
        type,
        data: base64 ? `data:${mimeType};base64,${base64}` : "",
        ...(asset.url ? { url: asset.url } : {}),
    };
}
