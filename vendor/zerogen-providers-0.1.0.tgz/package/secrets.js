/**
 * Provider → environment-variable name for its API key. Only the NAME is a
 * stable reference; the value is read at call time (BYOK) and never persisted.
 */
export const PROVIDER_SECRETS = {
    openai: "OPENAI_API_KEY",
    byteplus: "BYTEPLUS_API_KEY",
    fal: "FAL_KEY",
    elevenlabs: "ELEVENLABS_API_KEY",
};
/** Resolve a provider's API key from explicit BYOK value, then its env var. */
export function resolveApiKey(provider, apiKey) {
    return apiKey?.trim() || process.env[PROVIDER_SECRETS[provider]]?.trim() || undefined;
}
/**
 * The env var NAME a non-BYOK run would actually read for this provider, for
 * accurate manifest provenance. BytePlus accepts ARK_API_KEY as an alias, so
 * report that when it is the credential present.
 */
export function resolvedSecretRef(provider) {
    if (provider === "byteplus" &&
        !process.env.BYTEPLUS_API_KEY?.trim() &&
        process.env.ARK_API_KEY?.trim()) {
        return "ARK_API_KEY";
    }
    return PROVIDER_SECRETS[provider] ?? "";
}
